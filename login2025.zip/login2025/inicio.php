<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bienvenido</title>
  <style>
    body {
      font-family: "Poppins", Arial, sans-serif;
      background: linear-gradient(135deg, #48bb78, #38a169);
      color: white;
      display: flex; flex-direction: column;
      justify-content: center; align-items: center;
      height: 100vh; margin: 0;
      text-align: center;
    }
    .card {
      background: rgba(255,255,255,0.1);
      padding: 2rem 3rem;
      border-radius: 16px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.2);
      backdrop-filter: blur(10px);
      animation: aparecer 0.8s ease;
    }
    @keyframes aparecer { from {opacity:0; transform:translateY(20px);} to {opacity:1; transform:translateY(0);} }
    h1 { font-size: 2rem; margin-bottom: 0.5rem; }
    p { font-size: 1.1rem; opacity: 0.9; }
    a {
      display:inline-block; margin-top:1.5rem;
      background:white; color:#2f855a;
      padding:10px 20px; border-radius:8px;
      text-decoration:none; font-weight:600;
      transition:background 0.3s ease;
    }
    a:hover { background:#e6fffa; }
  </style>
</head>
<body>
  <div class="card">
    <h1>¡Bienvenido!</h1>
    <p>Has iniciado sesión correctamente.</p>
    <a href="index.html">Cerrar sesión</a>
  </div>
</body>
</html>
