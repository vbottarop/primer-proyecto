<?php
// Credenciales válidas
$usuario_correcto = "admin";
$clave_correcta = "1234";

// Verificar si se envió el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['usuario'];
    $clave = $_POST['clave'];

    // Validar los datos
    if ($usuario === $usuario_correcto && $clave === $clave_correcta) {
        $mensaje = "Bienvenido, $usuario 🎉";
        $color_fondo = "linear-gradient(135deg, #48bb78, #38a169)";
        $texto = "Has iniciado sesión correctamente.";
        $boton = "Cerrar sesión";
        $link = "login.html";
    } else {
        $mensaje = "¡Error!";
        $color_fondo = "linear-gradient(135deg, #e53e3e, #c53030)";
        $texto = "Usuario o contraseña incorrectos.";
        $boton = "Volver al login";
        $link = "login.html";
    }
} else {
    header("Location: login.html");
    exit();
}
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login PHP</title>
  <style>
    body {
      font-family: "Poppins", Arial, sans-serif;
      background: <?= $color_fondo ?>;
      color: white;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      text-align: center;
    }

    .card {
      background: rgba(255, 255, 255, 0.1);
      padding: 2rem 3rem;
      border-radius: 16px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      backdrop-filter: blur(10px);
      animation: aparecer 0.8s ease;
    }

    @keyframes aparecer {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    h1 { font-size: 2rem; margin-bottom: 0.5rem; }
    p { font-size: 1.1rem; opacity: 0.9; }

    a {
      display: inline-block;
      margin-top: 1.5rem;
      background: white;
      color: #333;
      padding: 10px 20px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: 600;
      transition: background 0.3s ease;
    }

    a:hover { background: #f0f0f0; }
  </style>
</head>
<body>
  <div class="card">
    <h1><?= $mensaje ?></h1>
    <p><?= $texto ?></p>
    <a href="<?= $link ?>"><?= $boton ?></a>
  </div>
</body>
</html>
