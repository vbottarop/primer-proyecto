<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Error de inicio de sesión</title>
  <style>
    body {
      background-color: #fff5f5;
      font-family: Arial, sans-serif;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 100vh;
      color: #e53e3e;
    }
    .error-box {
      background: white;
      border: 2px solid #e53e3e;
      padding: 20px 40px;
      border-radius: 10px;
      text-align: center;
    }
    a {
      display: inline-block;
      margin-top: 15px;
      text-decoration: none;
      color: white;
      background-color: #2b6cb0;
      padding: 10px 20px;
      border-radius: 5px;
    }
  </style>
</head>
<body>
  <div class="error-box">
    <h2>⚠️ Usuario o contraseña incorrectos</h2>
    <p>Por favor, intentá nuevamente.</p>
    <a href="index.html">Volver al login</a>
  </div>
</body>
</html>